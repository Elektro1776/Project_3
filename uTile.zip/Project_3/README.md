# Project_3
How uTile should have been built from the beginning. P.s. fuck handlebars, React for the win!

# How to start
  * install linter, linter-eslint, linter-ui-default on atom or vb(hopefully they exist similarly in its ecosystem... ben ;) )     packages. They make life better
  * Run yarn install
  * cd `client && yarn install`
  * cd `../ && npm start` or `npm run dev` to get the reload server going
